//体重が68
//身長が1.7
//console.log(体重/(身長*身長))

const weight=68;
const height=1.7;
console.log(weight/(height*height));